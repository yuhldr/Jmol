Clazz.declarePackage("JM");
Clazz.load(["JM.MinObject"], "JM.MinTorsion", null, function(){
var c$ = Clazz.decorateAsClass(function(){
Clazz.instantialize(this, arguments);
}, JM, "MinTorsion", JM.MinObject);
Clazz.makeConstructor(c$, 
function (data) {
Clazz.superConstructor (this, JM.MinTorsion, []);
this.data = data;
}, "~A");
});
;//5.0.1-v2 Mon Nov 27 23:35:08 CST 2023
