Clazz.declarePackage("JM");
Clazz.load(["JM.BioPolymer"], "JM.CarbohydratePolymer", null, function(){
var c$ = Clazz.decorateAsClass(function(){
Clazz.instantialize(this, arguments);
}, JM, "CarbohydratePolymer", JM.BioPolymer);
Clazz.makeConstructor(c$, 
function (monomers) {
Clazz.superConstructor (this, JM.CarbohydratePolymer, []);
this.set(monomers);
this.type = 3;
}, "~A");
});
;//5.0.1-v2 Mon Nov 27 23:35:08 CST 2023
