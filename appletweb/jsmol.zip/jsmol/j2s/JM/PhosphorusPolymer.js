Clazz.declarePackage("JM");
Clazz.load(["JM.BioPolymer"], "JM.PhosphorusPolymer", null, function(){
var c$ = Clazz.decorateAsClass(function(){
Clazz.instantialize(this, arguments);
}, JM, "PhosphorusPolymer", JM.BioPolymer);
Clazz.makeConstructor(c$, 
function (monomers) {
Clazz.superConstructor (this, JM.PhosphorusPolymer, []);
this.set(monomers);
this.hasStructure = true;
}, "~A");
});
;//5.0.1-v2 Mon Nov 27 23:35:08 CST 2023
