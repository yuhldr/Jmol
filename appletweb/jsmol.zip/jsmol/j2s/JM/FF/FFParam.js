Clazz.declarePackage("JM.FF");
(function(){
var c$ = Clazz.decorateAsClass(function(){
this.iVal = null;
this.dVal = null;
this.sVal = null;
Clazz.instantialize(this, arguments);
}, JM.FF, "FFParam", null);
})();
;//5.0.1-v2 Mon Nov 27 23:35:08 CST 2023
