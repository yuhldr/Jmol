Clazz.declarePackage("JS");
Clazz.load(["JS.LayoutManager"], "JS.FlowLayout", null, function(){
var c$ = Clazz.decorateAsClass(function(){
Clazz.instantialize(this, arguments);
}, JS, "FlowLayout", JS.LayoutManager);
});
;//5.0.1-v2 Mon Nov 27 23:35:08 CST 2023
