Clazz.declarePackage("JS");
(function(){
var c$ = Clazz.decorateAsClass(function(){
Clazz.instantialize(this, arguments);
}, JS, "InvalidSmilesException", Exception);
c$.getLastError = Clazz.defineMethod(c$, "getLastError", 
function () {
return JS.InvalidSmilesException.lastError;
});
c$.clear = Clazz.defineMethod(c$, "clear", 
function () {
JS.InvalidSmilesException.lastError = null;
});
Clazz.overrideMethod(c$, "getMessage", 
function () {
return JS.InvalidSmilesException.lastError;
});
Clazz.makeConstructor(c$, 
function (message) {
Clazz.superConstructor(this, JS.InvalidSmilesException, [message]);
JS.InvalidSmilesException.lastError = (message.startsWith("Jmol SMILES") ? message : "Jmol SMILES Exception: " + message);
}, "~S");
c$.lastError = null;
})();
;//5.0.1-v2 Mon Nov 27 23:35:08 CST 2023
