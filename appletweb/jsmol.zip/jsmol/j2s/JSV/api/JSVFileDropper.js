Clazz.declarePackage("JSV.api");
Clazz.declareInterface(JSV.api, "JSVFileDropper");
;//5.0.1-v2 Mon Nov 27 23:35:08 CST 2023
