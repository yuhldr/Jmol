Clazz.declarePackage("JSV.api.js");
Clazz.declareInterface(JSV.api.js, "JSVToJSmolInterface", javajs.api.js.J2SObjectInterface);
;//5.0.1-v2 Mon Nov 27 23:35:08 CST 2023
