Clazz.declarePackage("JSV.common");
Clazz.declareInterface(JSV.common, "XYScaleConverter");
;//5.0.1-v2 Mon Nov 27 23:35:08 CST 2023
